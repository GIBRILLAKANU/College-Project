package com.preving.intranet.restfulapi.model;

import com.preving.intranet.restfulapi.model.domain.Student;

import java.util.List;

public interface StudentsService {
    public List<Student> getAllStudents();
    public Student getStudentById(int studentId);
    public Student addOrUpdateStudent(Student student);
    public Student deleteStudent(int studentId) throws Exception;
}
